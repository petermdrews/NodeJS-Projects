module.exports = {
  secretKey: "12345-67890-09876-54321",
  mongoUrl: "mongodb://localhost:27017/nucampsite",
  facebook: {
    clientId: "326349712553061",
    clientSecret: "bb7d6b2fd6cdd026f3cb4fead5f09ca9",
  },
};
